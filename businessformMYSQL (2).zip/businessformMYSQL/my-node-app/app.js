//joshdemskie           


const http = require('http'); //module to create http server
const fs = require('fs');//file system
const path = require('path');//handle file paths
const mysql = require('mysql');//mysql database 

//node fetch(to test database easier atm)
import('node-fetch').then(({ default: fetch }) => {
  const hostname = '127.0.0.1';
  const port = 8080;

  // MySQL database connection
  const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'password', 
    database: 'my_database'
  });

//simple error
  connection.connect((err) => {
    if (err) {
      console.error('Error connecting to MySQL database:', err);
      return;
    }
    console.log('Connected to MySQL database successfully!');
  });

  // Function to handle HTTP POST requests(what saves to the DB)
  function handlePostRequest(req, res) {
    let body = '';
    req.on('data', (chunk) => {
      body += chunk.toString();
    });
    req.on('end', () => {
      // Parse form data
      const formData = new URLSearchParams(body);
      const phoneNumber = formData.get('phoneNumber');

      // Insert the phone number into the database
      connection.query('INSERT INTO phone_numbers (number) VALUES (?)', [phoneNumber], (err, result) => {
        if (err) {
          console.error('Error inserting phone number:', err);
          res.writeHead(500);
          res.end('Error inserting phone number');
          return;
        }
        console.log('Thank you! We will call you back soon!');
        res.writeHead(200, { 'Content-Type': 'text/plain' });
        res.end('Phone number inserted successfully!');
      });
    });
  }

  // Function to handle HTTP GET requests (what retrieves from the DB)
  function handleGetRequest(req, res) {
    // Retrieve phone numbers from the database
    connection.query('SELECT * FROM phone_numbers', (err, rows) => {
      if (err) {
        console.error('Error retrieving phone numbers:', err);
        res.writeHead(500);
        res.end('Error retrieving phone numbers');
        return;
      }
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(rows));
    });
  }
//creates the http server
  const server = http.createServer((req, res) => {
    if (req.method === 'POST' && req.url === '/save') {
      //post request
      handlePostRequest(req, res);
    } else if (req.method === 'GET' && req.url === '/get') {
      // get request
      handleGetRequest(req, res);
    } else {
      
      fs.readFile(path.join(__dirname, 'index.html'), (err, data) => {
        if (err) {
          res.writeHead(500);
          res.end('Error loading index.html');
        } else {
          res.writeHead(200, { 'Content-Type': 'text/html' });
          res.end(data);
        }
      });
    }
  });

  server.listen(port, hostname, () => {
    console.log(`Server running at http://${hostname}:${port}/`);
  });
});